`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////////
//// Company: Akron Research Company
//// Engineer: Bennett Miller
//// 
//// Create Date: 08/31/2026 11:11:50 PM
//// Design Name: simple_dff
//// Module Name: dff
//// Project Name: simple_dff
//// Target Devices: Any
//// Tool Versions: Any
//// Description: Simple D Flip Flop
//// 
//// Dependencies: None
//// 
//// Revision: 
//// Revision 0.01 - File Created
//// Additional Comments:
//// Experimentation done on a Diligent Basys 3
////////////////////////////////////////////////////////////////////////////////////

module dff(clk, d, q);
    input clk, d;
    output reg q;
    
    always @(posedge clk) begin
        q <= d;
    end
endmodule